#include <stdio.h>
int main() {
    int n ;
    
    printf("Enter Num :") ;
    scanf("%d",&n) ;

    /// Enter Loop ;
    int i ;
    int j ;
    
    for (i=0 ; i<n ; i=i+1) {
        
        for (j=0 ; j<n-1 ; j=j+1) {
            printf(" ") ;
        }

        for (j=0 ; j<=i ; j=j+1) {
            printf("* ") ;

        }
        printf("\n") ;
    
    }
}