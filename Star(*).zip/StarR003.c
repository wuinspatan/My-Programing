#include <stdio.h>

int main() {

    int h ;

    printf("EnTERnum :") ;
    scanf("%d",&h) ;

    /// En Loop row i

    int i ;
    int j ;
     
    for ( i=0 ; i<h ; i=i+1 ) {
        
        for ( j=0 ; j<=i ; j=j+1 ) {
            printf(" ") ;
        }

        for (j=0 ; j<h-i ; j=j+1) {
            printf("*") ;
        }
        
        /// New Line 
        printf("\n") ;

    }

}