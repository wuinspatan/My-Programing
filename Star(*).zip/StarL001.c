#include <stdio.h>
int main() {

    int n ; 

    printf("N :") ;
    scanf("%d",&n) ;

    int i ;
    int j ;
    
    /// Enter Loop 

    for (i=0 ; i<n ; i=i+1) {
        
        for (j=0 ;j<=n-i-1 ; j=j+1) { 
            printf("*") ;
        }

        for (j=0 ; j<=n+1+i ; j=j+1) {
            printf(" ") ;
        }
        printf("\n") ;
    }   


}