#include <stdio.h>

int main() {
    int n;
    int i;
    int j;

    printf("Enter Num: ");
    scanf("%d", &n);

    for ( i=0 ; i<n ; i=i+1 ) {

        for (j=0; j<n-i-1; j=j+1 ) {
            printf("  ");
        }

        for ( j=0; j<=i ; j=j+1 ) {
            printf("* ");
        }
        printf("\n");  
    }

}
